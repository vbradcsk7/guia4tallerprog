package ar.almundo.callcenter.enumerator;

public enum EmployeeState {
	AVAILABLE, BUSY
}
